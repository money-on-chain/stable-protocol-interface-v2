import React, { Fragment, useContext, useEffect, useState } from 'react';
import './Styles.scss';

export default function HomeTabs({ tabs }) {
    // Estado para controlar la pestaña activa
    const [activeTab, setActiveTab] = useState(tabs[0].name);

    // Renderizar el contenido según la pestaña activa
    const renderContent = () => {
        const activeTabContent = tabs.find((tab) => tab.name === activeTab);
        return activeTabContent ? activeTabContent.content : null;
    };

    return (
        <>
            {/* TabBar Buttons*/}
            <div className="tab__container">
                {tabs.map((tab) => (
                    <button
                        key={tab.name}
                        className={
                            activeTab === tab.name
                                ? 'tab__button > tab__selected'
                                : 'tab__button'
                        }
                        onClick={() => setActiveTab(tab.name)}
                    >
                        {tab.name}
                    </button>
                ))}
            </div>

            {/* Content based on selected tab */}
            <div>
                {tabs.map((tab) => (
                    <div
                        key={tab.name}
                        style={{
                            display: activeTab === tab.name ? 'block' : 'none'
                        }}
                    >
                        {tab.content}
                    </div>
                ))}
            </div>
        </>
    );
}
